# @antelopejs/interface-core

<div align="center">
<a href="https://www.npmjs.com/package/@antelopejs/interface-core"><img alt="npm" src="https://img.shields.io/npm/v/@antelopejs/interface-core?style=for-the-badge&labelColor=000000&color=000000"></a>
<a href="./LICENSE"><img alt="License" src="https://img.shields.io/npm/l/@antelopejs/interface-core?style=for-the-badge&labelColor=000000&color=000000"></a>
<a href="https://discord.gg/sjK28QHrA7"><img alt="Discord" src="https://img.shields.io/badge/Discord-18181B?logo=discord&style=for-the-badge&color=000000"></a>
<a href="https://interfaces.antelopejs.com/docs/core"><img alt="Docs" src="https://img.shields.io/badge/Docs-18181B?style=for-the-badge&color=000000"></a>
</div>

The primitives every AntelopeJS interface is built from: proxies that cross module boundaries, decorator factories, module lifecycle events, structured logging and project configuration.

## What it offers

- `InterfaceFunction` declares a contract function; `ImplementInterface` attaches a module's implementation to it. Calls made before the implementation attaches wait in a queue.
- `AsyncProxy`, `EventProxy` and `RegisteringProxy` carry calls, events and registrations between modules, and detach when a module unloads.
- `@antelopejs/interface-core/decorators` builds typed class, method, property and parameter decorators.
- `@antelopejs/interface-core/modules` exposes lifecycle events and module management functions.
- `@antelopejs/interface-core/logging` writes structured logs on named channels; `@antelopejs/interface-core/config` provides `defineConfig` for `antelope.config.ts`.

## Implementations

| Module                                                         | Notes                                                         |
| -------------------------------------------------------------- | ------------------------------------------------------------- |
| [`@antelopejs/core`](https://github.com/AntelopeJS/antelopejs) | The AntelopeJS runtime and `ajs` CLI implement this interface |

## Install

Add the package to any module that declares or implements an interface:

```bash
pnpm add @antelopejs/interface-core
```

No extra module is needed: the core provides the implementation.

## Quick start

Declare a contract:

```ts
// src/interface/index.ts
import { InterfaceFunction } from "@antelopejs/interface-core";

export const GetGreeting = InterfaceFunction<(name: string) => string>();
```

Implement it and call it from a module:

```ts fragment
// src/index.ts
import { ImplementInterface } from "@antelopejs/interface-core";
import { Logging } from "@antelopejs/interface-core/logging";
import * as Greeting from "./interface";

export function construct() {
  ImplementInterface(Greeting, {
    GetGreeting: (name: string) => `Hello, ${name}`,
  });
}

export async function start() {
  Logging.Info(await Greeting.GetGreeting("Ada"));
}
```

An interface function always returns a promise, even when the implementation is synchronous.

## Documentation

- [Introduction](./docs/1.introduction.md)
- [Proxies, attachment leases and errors](./docs/2.proxies.md)
- [Decorators](./docs/3.decorators.md)
- [Metadata](./docs/4.metadata.md)
- [Modules](./docs/5.modules.md)
- [Logging](./docs/6.logging.md)
- [Configuration](./docs/7.configuration.md)
- [Runtime](./docs/8.runtime.md)

## Compatibility

`@antelopejs/core` implements this package. Each core release declares the `@antelopejs/interface-core` range it works with in the `dependencies` of its `package.json`.

## Contributing

Read [CONTRIBUTING.md](./CONTRIBUTING.md) before you open a pull request. The local checks are:

```bash
pnpm install
pnpm lint
pnpm test
```

## License

[Apache-2.0](./LICENSE)
