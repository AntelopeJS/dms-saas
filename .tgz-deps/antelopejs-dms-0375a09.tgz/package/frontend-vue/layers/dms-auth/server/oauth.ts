import { timingSafeEqual } from "node:crypto";
import type { DmsServerEvent } from "#dms/server";
import { privateSecret } from "../../../server/private-options";
import { persistAccountSession } from "./accounts";
import { type SessionTokens, sessionFrom } from "./session";
import type {
  NoHandoff,
  NoWorkspaceHandoff,
  TwoFactorHandoff,
} from "../shared/oauth";
import {
  isNumber,
  isObject,
  isString,
} from "../../dms-core/app/utils/type-check";

const FLOW = "dms_oauth_flow";
const HANDOFF = "dms_oauth_handoff";
const FLOW_PATH = "/auth/oauth";
const COMPLETE = "/auth/oauth/complete";
const SIGN_IN = "/auth";
const OAUTH_ERROR = "error.oauth.";
const FAILED = "error.oauth.failed";
const FLOW_LIFETIME_MS = 10 * 60 * 1000;
const HANDOFF_LIFETIME_S = 300;
const RATE_WINDOW_MS = 60 * 1000;
const RATE_LIMIT = 10;
const MAX_RATE_LIMIT_CLIENTS = 10_000;
const MAX_CALLBACK_PARAMETER_LENGTH = 2048;
const PROVIDER = /^[a-z0-9-]{1,32}$/;

interface RateWindow {
  count: number;
  startedAt: number;
}

interface OAuthFlow {
  state: string;
  expiresAt: number;
  redirect: string;
  language: string;
  invite: string;
}

interface OAuthResult extends SessionTokens {
  requires_2fa?: boolean;
  requires_tenant_assignment?: boolean;
  two_factor_token?: string;
  tenant_assignment_token?: string;
  methods?: unknown;
}

const attempts = new Map<string, RateWindow>();

function isOAuthFlow(value: unknown): value is OAuthFlow {
  return (
    isObject(value) &&
    value !== null &&
    isString(value.state) &&
    isNumber(value.expiresAt) &&
    isString(value.redirect) &&
    isString(value.language) &&
    isString(value.invite)
  );
}

function isTextList(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(isString);
}

function isOAuthHandoff(
  value: unknown,
): value is TwoFactorHandoff | NoWorkspaceHandoff {
  if (!isObject(value) || value === null) return false;
  if (value.kind === "2fa")
    return isString(value.token) && isTextList(value.methods);
  return (
    value.kind === "no-workspace" &&
    isString(value.token) &&
    isString(value.provider)
  );
}

function sweepAttempts(now: number) {
  for (const [key, window] of attempts)
    if (now - window.startedAt >= RATE_WINDOW_MS) attempts.delete(key);
  while (attempts.size >= MAX_RATE_LIMIT_CLIENTS) {
    const [oldest] = attempts.keys();
    if (oldest === undefined) return;
    attempts.delete(oldest);
  }
}

/** Counts an attempt for `key`; false once over the limit of the window. */
export function hitOAuthRateLimitKey(key: string, now = Date.now()): boolean {
  sweepAttempts(now);
  const window = attempts.get(key);
  if (!window || now - window.startedAt >= RATE_WINDOW_MS) {
    attempts.set(key, { count: 1, startedAt: now });
    return true;
  }
  window.count += 1;
  return window.count <= RATE_LIMIT;
}

function rateLimited(event: DmsServerEvent, scope: string): boolean {
  return !hitOAuthRateLimitKey(`${scope}:${event.clientIp()}`);
}

export function isValidOAuthProvider(provider: unknown): provider is string {
  return isString(provider) && PROVIDER.test(provider);
}

function safePath(value: string | null): string {
  if (
    !isString(value) ||
    !value.startsWith("/") ||
    value.startsWith("//") ||
    value.includes("\\")
  )
    return "";
  try {
    const decoded = decodeURIComponent(value);
    return decoded.startsWith("//") || decoded.includes("\\") ? "" : value;
  } catch {
    return "";
  }
}

function redirect(location: string): Response {
  return new Response(null, { status: 302, headers: { location } });
}

function errorRedirect(key: string): Response {
  return redirect(`${SIGN_IN}?oauth_error=${encodeURIComponent(key)}`);
}

function failureRedirect(error: unknown): Response {
  const message = error instanceof Error ? error.message : "";
  const status = (error as { status?: unknown }).status;
  return errorRedirect(
    isNumber(status) && message.startsWith(OAUTH_ERROR) ? message : FAILED,
  );
}

function relayHeaders(event: DmsServerEvent) {
  const secret = privateSecret(
    event,
    "oauth",
    "relaySecret",
    "DMS_OAUTH_RELAY_SECRET",
  );
  return { "x-dms-oauth-relay": secret ?? "" };
}

/** `GET /auth/oauth/:provider/start`: on to the provider's sign-in page. */
export async function oauthStart(event: DmsServerEvent): Promise<Response> {
  const { provider } = event.params;
  if (
    !isValidOAuthProvider(provider) ||
    event.request.headers.get("sec-fetch-site") === "cross-site" ||
    rateLimited(event, "start")
  )
    return errorRedirect(FAILED);
  try {
    const result = await event.backend<{
      state: string;
      authorizeUrl: string;
    }>(`/api/auth/oauth/${provider}/authorize-url`, {
      headers: relayHeaders(event),
    });
    const query = event.url.searchParams;
    event.cookies.writeSealed(
      FLOW,
      {
        state: result.state,
        expiresAt: Date.now() + FLOW_LIFETIME_MS,
        redirect: safePath(query.get("redirect")),
        language: query.get("language") ?? "",
        invite: query.get("invite") ?? "",
      } satisfies OAuthFlow,
      { maxAge: FLOW_LIFETIME_MS / 1000, path: FLOW_PATH },
    );
    return redirect(result.authorizeUrl);
  } catch (error) {
    return failureRedirect(error);
  }
}

function sameState(
  left: OAuthFlow["state"],
  right: OAuthFlow["state"],
): boolean {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

function validCallback(flow: OAuthFlow | undefined, query: URLSearchParams) {
  const code = query.get("code");
  const state = query.get("state");
  return Boolean(
    flow &&
      flow.expiresAt >= Date.now() &&
      isString(code) &&
      code.length <= MAX_CALLBACK_PARAMETER_LENGTH &&
      isString(state) &&
      state.length <= MAX_CALLBACK_PARAMETER_LENGTH &&
      sameState(state, flow.state),
  );
}

function storeOAuthResult(
  event: DmsServerEvent,
  provider: string,
  result: OAuthResult,
) {
  const handoff = { maxAge: HANDOFF_LIFETIME_S, path: FLOW_PATH };
  if (result.requires_2fa)
    event.cookies.writeSealed(
      HANDOFF,
      { kind: "2fa", token: result.two_factor_token, methods: result.methods },
      handoff,
    );
  else if (result.requires_tenant_assignment)
    event.cookies.writeSealed(
      HANDOFF,
      {
        kind: "no-workspace",
        token: result.tenant_assignment_token,
        provider,
      },
      handoff,
    );
  else persistAccountSession(event, sessionFrom(result));
}

async function completeOAuth(
  event: DmsServerEvent,
  provider: string,
  flow: OAuthFlow,
): Promise<Response> {
  const query = event.url.searchParams;
  try {
    const result = await event.backend<OAuthResult>(
      `/api/auth/oauth/${provider}/callback`,
      {
        method: "POST",
        headers: relayHeaders(event),
        body: {
          code: query.get("code"),
          state: query.get("state"),
          state_cookie: flow.state,
          language: flow.language || undefined,
          invite: flow.invite || undefined,
        },
      },
    );
    storeOAuthResult(event, provider, result);
    return redirect(
      flow.redirect &&
        !result.requires_2fa &&
        !result.requires_tenant_assignment
        ? `${COMPLETE}?redirect=${encodeURIComponent(flow.redirect)}`
        : COMPLETE,
    );
  } catch (error) {
    return failureRedirect(error);
  }
}

/** `GET /auth/oauth/:provider/callback`: back from the provider. */
export async function oauthCallback(event: DmsServerEvent): Promise<Response> {
  const { provider } = event.params;
  if (!isValidOAuthProvider(provider) || rateLimited(event, "callback"))
    return errorRedirect(FAILED);
  const flow = event.cookies.readSealed(FLOW, isOAuthFlow);
  event.cookies.clear(FLOW, { path: FLOW_PATH });
  const query = event.url.searchParams;
  if (query.has("error")) return errorRedirect("error.oauth.cancelled");
  if (!flow || !validCallback(flow, query))
    return errorRedirect("error.oauth.invalid_state");
  return completeOAuth(event, provider, flow);
}

/**
 * `POST /auth/oauth/handoff`: what the provider sign-in left for the page to
 * finish (a 2FA step, a workspace to pick), once.
 */
export function oauthHandoff(event: DmsServerEvent) {
  const handoff: TwoFactorHandoff | NoWorkspaceHandoff | NoHandoff =
    event.cookies.readSealed(HANDOFF, isOAuthHandoff) ?? { kind: "none" };
  event.cookies.clear(HANDOFF, { path: FLOW_PATH });
  return handoff;
}
